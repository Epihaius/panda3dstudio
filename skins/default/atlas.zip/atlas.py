text = """# Panda3D Studio texture atlas data
#
REGIONS
#
# The regions in the texture atlas that correspond to the listed widget parts, in the
# following format:
# [widget part] [x coordinate] [y coordinate] [width] [height]
#
# NOTES:
#
# *) If the normal state of a button or combobox is completely transparent, it does not need to
#    be part of the texture atlas.
#
# *) If the disabled state of a button or combobox is not in the texture atlas, its normal state
#    graphic will be used instead.
#
# *) When a center part is resized to stretch a widget, its texture is stretched if it is only
#    one pixel high or wide, otherwise it is tiled.
#
"""

with open("atlas.txt", "w") as atlas_file:
    atlas_file.write(text)
    with open("regions.txt", "r") as regions_file:
        atlas_file.writelines (regions_file.readlines())
    atlas_file.write("#\n")
    with open("borders.txt", "r") as borders_file:
        atlas_file.writelines (borders_file.readlines())
