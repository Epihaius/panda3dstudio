#!/usr/bin/env python
#
# This script generates a texture atlas for a Panda3D Studio "skin".
# It needs to be run in a directory containing:
#   *) the graphics files to be assembled into the texture atlas;
#   *) `borders.txt`: defines inner and outer borders for various widgets;
#   *) `gfx_ids.txt`: defines which image files are used for which widgets.
#
# Two files will be generated: `atlas.png` and `atlas.txt`. These need to be
# placed in a user-created subdirectory of the `skins` directory.
# If this subdirectory is chosen when selecting a skin in Panda3D Studio, the
# generated atlas will be used to create the graphics for the GUI.

from panda3d.core import PNMImage
import os


grid = []


class Cell:

    __slots__ = ("x", "y", "width", "height", "name", "row", "is_start",
        "image", "cell_right", "cell_below")

    def __init__(self, x, y, width, height, row=0, is_start=False):

        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.name = None
        self.image = None
        self.row = row
        self.is_start = is_start
        self.cell_right = None
        self.cell_below = None

        if self.row >= 0:
            if is_start:
                grid.append([self])
            else:
                grid[row].append(self)

    def __fill_holes(self):

        x = self.x + self.width

        for cell in grid[self.row-1]:
            if cell.x < x:
                if self.x <= cell.x:
                    width = min(cell.width, x - cell.x)
                    y = cell.y + cell.height
                    height =  self.y - y
                    if height:
                        cell.cell_below = Cell(cell.x, y, width, height, -1)
            else:
                break

    def fit_image(self, image, name):

        if self.image:
            if self.cell_right.fit_image(image, name):
                return True
            if self.cell_below:
                return self.cell_below.fit_image(image, name)
            return False

        width, height = image.size

        if width > self.width or height > self.height:
            return False

        x = self.x + width
        y = self.y

        if self.row > 0:
            for cell in grid[self.row-1]:
                if cell.x <= x < cell.x + cell.width:
                    y = cell.y + cell.height
                    break

        cell_height = self.height if self.row < 0 else height
        self.cell_right = Cell(x, y, self.width - width, cell_height, self.row)

        if self.row >= 0 and self.is_start:
            self.cell_below = Cell(self.x, self.y + height, self.width,
                self.height - height, self.row + 1, self.is_start)

        self.width = width
        self.height = height
        self.image = image
        self.name = name

        if self.row > 0:
            self.__fill_holes()

        return True

    def add_subimages(self, image):

        if not self.image:
            return

        image.blend_sub_image(self.image, self.x, self.y, 0, 0)
        self.cell_right.add_subimages(image)

        if self.cell_below:
            self.cell_below.add_subimages(image)

    def write_regions(self, atlas_file):

        if not self.image:
            return

        atlas_file.write(f"{self.name} {self.x} {self.y} {self.width} {self.height}\n")
        self.cell_right.write_regions(atlas_file)

        if self.cell_below:
            self.cell_below.write_regions(atlas_file)


unsorted_images = []
image_names = {}

# load all images
for name in os.listdir("."):

    basename, ext = os.path.splitext(name)

    if ext == ".png".lower():

        image = PNMImage(0, 0, 4)
        image.read(name)

        if not image.has_alpha():
            image.add_alpha()
            image.alpha_fill(1.)

        unsorted_images.append(image)
        image_names[image] = basename

# sort images by height, from highest to lowest
images = sorted(unsorted_images, key=PNMImage.get_y_size, reverse=True)

res = 32
atlas = Cell(0, 0, res, res, 0, True)


def build_atlas():

    # try to fit images in atlas
    for image in images:
        if not atlas.fit_image(image, image_names[image]):
            return False

    return True


# rebuild the atlas until it's big enough to fit all images
while not build_atlas():
    res *= 2
    atlas.width = atlas.height = res
    atlas.image = None
    grid[:] = [[atlas]]

# create atlas image and write it to "atlas.png"
atlas_image = PNMImage(res, res, 4)
atlas.add_subimages(atlas_image)
atlas_image.write("atlas.png")

text = """# Panda3D Studio texture atlas data
#
REGIONS
#
# The regions in the texture atlas that correspond to the listed widget parts, in the
# following format:
# [widget part] [x coordinate] [y coordinate] [width] [height]
#
# NOTES:
#
# *) If the normal state of a button or combobox is completely transparent, it does not need to
#    be part of the texture atlas.
#
# *) If the disabled state of a button or combobox is not in the texture atlas, its normal state
#    graphic will be used instead.
#
# *) When a center part is resized to stretch a widget, its texture is stretched if it is only
#    one pixel high or wide, otherwise it is tiled.
#
"""

with open("atlas.txt", "w") as atlas_file:

    atlas_file.write(text)

    # write region coordinates and sizes to "atlas.txt"
    atlas.write_regions(atlas_file)

    atlas_file.write("#\n")

    with open("gfx_ids.txt", "r") as gfx_ids_file:
        atlas_file.writelines(gfx_ids_file.readlines())

    atlas_file.write("#\n")

    with open("borders.txt", "r") as borders_file:
        atlas_file.writelines(borders_file.readlines())
